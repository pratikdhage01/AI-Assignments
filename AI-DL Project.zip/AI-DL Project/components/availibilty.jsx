"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Clock, Plus, AlertCircle, Calendar, RefreshCw } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function AvailabilitySettings() {
  const [showForm, setShowForm] = useState(false);
  const [selectedLawyer, setSelectedLawyer] = useState("");
  const [isSyncing, setIsSyncing] = useState(false);
  const [formData, setFormData] = useState({
    startTime: "",
    endTime: ""
  });

  // Mock lawyers data with Google Calendar integration
  const lawyers = [
    { id: "lawyer1", name: "Lawyer 1", calendarId: "lawyer1@example.com" },
    { id: "lawyer2", name: "Lawyer 2", calendarId: "lawyer2@example.com" },
    { id: "lawyer3", name: "Lawyer 3", calendarId: "lawyer3@example.com" }
  ];

  // Mock slots data
  const mockSlots = [
    { id: 1, startTime: "2023-12-15T09:00:00", endTime: "2023-12-15T12:00:00", appointment: false },
    { id: 2, startTime: "2023-12-15T14:00:00", endTime: "2023-12-15T17:00:00", appointment: true }
  ];

  // Format time string for display
  const formatTimeString = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return "Invalid time";
    }
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!selectedLawyer) {
      alert("Please select a lawyer first");
      return;
    }

    // Mock adding a new slot
    const newSlot = {
      id: Date.now(),
      lawyer: selectedLawyer,
      startTime: `2023-12-15T${formData.startTime}:00`,
      endTime: `2023-12-15T${formData.endTime}:00`,
      appointment: false
    };
    
    // Here you would typically send this to your backend
    console.log("New slot to be synced with Google Calendar:", newSlot);
    
    // Mock VAPI agent integration
    syncWithGoogleCalendar(newSlot);
    
    setFormData({ startTime: "", endTime: "" });
    setShowForm(false);
  };

  // Mock function to sync with Google Calendar via VAPI agent
  const syncWithGoogleCalendar = async (slotData) => {
    setIsSyncing(true);
    
    try {
      // This would be replaced with actual VAPI agent API call
      console.log("Syncing with Google Calendar for lawyer:", selectedLawyer);
      console.log("Slot data:", slotData);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock successful sync
      alert(`Successfully synced availability with ${selectedLawyer}'s Google Calendar!`);
      
    } catch (error) {
      console.error("Failed to sync with Google Calendar:", error);
      alert("Failed to sync with Google Calendar. Please try again.");
    } finally {
      setIsSyncing(false);
    }
  };

  // Mock function to fetch current calendar availability
  const fetchGoogleCalendarAvailability = async () => {
    if (!selectedLawyer) {
      alert("Please select a lawyer first");
      return;
    }
    
    setIsSyncing(true);
    
    try {
      // This would be replaced with actual Google Calendar API call
      console.log("Fetching Google Calendar availability for:", selectedLawyer);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock fetched data
      alert(`Fetched current availability from ${selectedLawyer}'s Google Calendar!`);
      
    } catch (error) {
      console.error("Failed to fetch calendar data:", error);
      alert("Failed to fetch calendar data. Please try again.");
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="text-2xl font-bold text-gray-900 flex items-center">
          <Calendar className="h-6 w-6 mr-2 text-blue-600" />
          Google Calendar Integration
        </CardTitle>
        <CardDescription className="text-gray-600 text-base">
          Manage availability and sync with Google Calendar
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Lawyer Selection */}
        <div className="mb-6">
          <Label htmlFor="lawyer-select" className="text-gray-700 font-medium mb-2 block">
            Select Lawyer
          </Label>
          <Select value={selectedLawyer} onValueChange={setSelectedLawyer}>
            <SelectTrigger className="w-full bg-white border-gray-300">
              <SelectValue placeholder="Choose a lawyer" />
            </SelectTrigger>
            <SelectContent>
              {lawyers.map((lawyer) => (
                <SelectItem key={lawyer.id} value={lawyer.id}>
                  {lawyer.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedLawyer && (
          <>
            {/* Sync Controls */}
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">
                    Google Calendar Sync
                  </h4>
                  <p className="text-sm text-gray-600">
                    Connected to {lawyers.find(l => l.id === selectedLawyer)?.name}'s calendar
                  </p>
                </div>
                <Button
                  onClick={fetchGoogleCalendarAvailability}
                  disabled={isSyncing}
                  variant="outline"
                  className="flex items-center"
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
                  {isSyncing ? 'Syncing...' : 'Refresh Calendar'}
                </Button>
              </div>
            </div>

            {/* Current Availability Display */}
            {!showForm ? (
              <>
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Current Availability
                  </h3>

                  {mockSlots.length === 0 ? (
                    <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                      <Clock className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                      <p className="text-gray-600">
                        No availability slots set yet. Add time slots to sync with Google Calendar.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {mockSlots.map((slot) => (
                        <div
                          key={slot.id}
                          className="flex items-center p-4 rounded-lg bg-white border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                        >
                          <div className="bg-blue-100 p-2 rounded-full mr-4">
                            <Clock className="h-5 w-5 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <p className="text-gray-900 font-medium text-lg">
                              {formatTimeString(slot.startTime)} - {formatTimeString(slot.endTime)}
                            </p>
                            <p className={`text-sm ${slot.appointment ? 'text-orange-600' : 'text-green-600'}`}>
                              {slot.appointment ? "• Booked" : "• Available"}
                            </p>
                          </div>
                          <div className={`w-3 h-3 rounded-full ${slot.appointment ? 'bg-orange-400' : 'bg-green-400'} animate-pulse`}></div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <Button
                  onClick={() => setShowForm(true)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-base"
                  size="lg"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Add Availability Slot
                </Button>
              </>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="space-y-6 bg-white p-6 rounded-lg border border-gray-200 shadow-sm"
              >
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Add New Availability Slot
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="startTime" className="text-gray-700 font-medium">
                      Start Time
                    </Label>
                    <Input
                      id="startTime"
                      name="startTime"
                      type="time"
                      value={formData.startTime}
                      onChange={handleInputChange}
                      className="bg-white border-gray-300 h-12 text-lg"
                      required
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="endTime" className="text-gray-700 font-medium">
                      End Time
                    </Label>
                    <Input
                      id="endTime"
                      name="endTime"
                      type="time"
                      value={formData.endTime}
                      onChange={handleInputChange}
                      className="bg-white border-gray-300 h-12 text-lg"
                      required
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowForm(false)}
                    className="border-gray-300 text-gray-700 hover:bg-gray-100"
                    size="lg"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                    size="lg"
                    disabled={isSyncing || !formData.startTime || !formData.endTime}
                  >
                    {isSyncing ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Syncing...
                      </>
                    ) : (
                      'Sync with Google Calendar'
                    )}
                  </Button>
                </div>
              </form>
            )}
          </>
        )}

        {/* Information Section */}
        <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
          <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
            <AlertCircle className="h-5 w-5 mr-2 text-blue-600" />
            How Google Calendar Integration Works
          </h4>
          <ul className="text-gray-700 text-sm space-y-2">
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              Select a lawyer to manage their Google Calendar availability
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              Add time slots that will be synced with their Google Calendar
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              VAPI agent automatically updates Google Calendar with new availability
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              Clients can book appointments only during available time slots
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              Real-time sync ensures no double bookings
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}