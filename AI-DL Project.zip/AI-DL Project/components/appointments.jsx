"use client";

import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalIcon } from "lucide-react";

export default function LawyerAppointmentsList() {
  // Read env (must be NEXT_PUBLIC_ prefixed and NEXT dev server restarted after editing)
  const raw = typeof process !== "undefined" ? process.env.NEXT_PUBLIC_CALENDAR_ID || "" : "";
  // remove accidental quotes/newlines and trim
  const calendarId = raw.replace(/^["']|["']$/g, "").trim();

  // Build iframe src safely
  const srcUrl = calendarId
    ? `https://calendar.google.com/calendar/embed?src=${encodeURIComponent(calendarId)}&ctz=Asia%2FKolkata`
    : null;

  useEffect(() => {
    console.log("[DEBUG] NEXT_PUBLIC_CALENDAR_ID raw:", raw);
    console.log("[DEBUG] cleaned calendarId:", calendarId);
    console.log("[DEBUG] iframe srcUrl:", srcUrl);
  }, [raw, calendarId, srcUrl]);

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center">
          <CalIcon className="h-6 w-6 mr-2 text-blue-600" />
          My Google Calendar
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!calendarId ? (
          <div className="p-4 text-sm text-red-600">
            <strong>Error:</strong> NEXT_PUBLIC_CALENDAR_ID not set or is invalid. <br />
            Put your calendar id in <code>.env.local</code> as <code>NEXT_PUBLIC_CALENDAR_ID=your_calendar_id@group.calendar.google.com</code> (no quotes), then restart the dev server.
          </div>
        ) : (
          <iframe
            title="Google Calendar"
            src={srcUrl}
            style={{ border: 0 }}
            width="100%"
            height="600"
            frameBorder="0"
            scrolling="no"
          />
        )}
      </CardContent>
    </Card>
  );
}
