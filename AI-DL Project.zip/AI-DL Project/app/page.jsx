"use client";

import {
  useUser,
  SignedIn,
  SignedOut,
  SignInButton,
  UserButton,
} from "@clerk/nextjs";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, MessageCircle, PhoneOff } from "lucide-react";
import Image from "next/image";

export default function Home() {
  const { user, isSignedIn } = useUser();
  const router = useRouter();

  const [vapi, setVapi] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [call, setCall] = useState(null);
  const [callStatus, setCallStatus] = useState("disconnected");
  const [eventHandlers, setEventHandlers] = useState(null);

  // 🔹 Helper function to check if error is meaningful
  const isMeaningfulError = (error) => {
    if (!error || typeof error !== "object") return false;
    try {
      const hasMessage =
        error.message &&
        typeof error.message === "string" &&
        error.message.trim().length > 0;
      const hasCode =
        error.code &&
        (typeof error.code === "string" || typeof error.code === "number");
      const hasName =
        error.name &&
        typeof error.name === "string" &&
        error.name.trim().length > 0;
      return hasMessage || hasCode || hasName;
    } catch {
      return false;
    }
  };

  // 🔹 Safe logger
  const safeLogError = (prefix, err) => {
    try {
      if (err instanceof Error) {
        console.error(prefix, {
          message: err.message,
          code: err.code,
          name: err.name,
          stack: err.stack,
        });
      } else {
        console.error(prefix, JSON.stringify(err, null, 2));
      }
    } catch {
      console.error(prefix, "Unknown error");
    }
  };

  // 🔹 Redirect admin to dashboard
  useEffect(() => {
    if (isSignedIn && user?.publicMetadata?.role === "admin") {
      router.replace("/admin-dashboard");
    }
  }, [isSignedIn, user, router]);

  // 🔹 Initialize Vapi
  useEffect(() => {
    if (!process.env.NEXT_PUBLIC_VAPI_API_KEY) {
      console.error("⚠️ Missing NEXT_PUBLIC_VAPI_API_KEY in .env.local");
      return;
    }

    const initializeVapi = async () => {
      try {
        const VapiModule = await import("@vapi-ai/web");
        const Vapi = VapiModule.default;
        const client = new Vapi(process.env.NEXT_PUBLIC_VAPI_API_KEY);
        setVapi(client);
        console.log("✅ Vapi initialized successfully");
      } catch (error) {
        safeLogError("❌ Error initializing Vapi:", error);
      }
    };

    initializeVapi();

    return () => {
      if (call) {
        try {
          if (typeof call.stop === "function") call.stop();
          else if (typeof call.end === "function") call.end();
          else if (typeof call.disconnect === "function") call.disconnect();
          else if (typeof call.hangUp === "function") call.hangUp();
        } catch (_) {}
      }

      if (eventHandlers) {
        const { call: callObj, vapi: vapiClient } = eventHandlers;
        if (callObj && typeof callObj.off === "function") {
          callObj.off("call-started");
          callObj.off("call-ended");
          callObj.off("error");
        }
        if (vapiClient && typeof vapiClient.off === "function") {
          vapiClient.off("call-started");
          vapiClient.off("call-ended");
          vapiClient.off("error");
        }
      }
    };
  }, []);

  // 🔹 Start call
  const handleStartCall = async () => {
    if (!isSignedIn) {
      router.push("/sign-in");
      return;
    }

    if (!vapi) {
      alert("Please wait, initializing call system...");
      return;
    }

    if (!process.env.NEXT_PUBLIC_VAPI_AGENT_ID) {
      alert("Configuration error. Missing agent ID.");
      return;
    }

    setIsLoading(true);
    setCallStatus("connecting");

    try {
      const newCall = await vapi.start(process.env.NEXT_PUBLIC_VAPI_AGENT_ID);

      if (!newCall) throw new Error("No call object returned");

      setCall(newCall);

      const onCallStarted = () => {
        setCallStatus("connected");
        setIsLoading(false);
      };

      const onCallEnded = () => {
        setCallStatus("ended");
        setCall(null);
        setEventHandlers(null);
        setTimeout(() => setCallStatus("disconnected"), 2000);
      };

      const onError = (error) => {
        try {
          if (isMeaningfulError(error)) {
            safeLogError("❌ Call error:", error);
            alert("❌ Call failed. Try again.");
          } else {
            console.log("ℹ️ Call ended with no meaningful error");
          }
        } catch (e) {
          console.error("⚠️ Error in onError handler:", e);
        } finally {
          setCallStatus("disconnected");
          setCall(null);
          setEventHandlers(null);
          setIsLoading(false);
        }
      };

      if (typeof newCall.on === "function") {
        newCall.on("call-started", onCallStarted);
        newCall.on("call-ended", onCallEnded);
        newCall.on("error", onError);
        setEventHandlers({ call: newCall, vapi: null });
      } else if (vapi && typeof vapi.on === "function") {
        vapi.on("call-started", onCallStarted);
        vapi.on("call-ended", onCallEnded);
        vapi.on("error", onError);
        setEventHandlers({ call: null, vapi });

        setTimeout(() => {
          setCallStatus((s) => (s === "connecting" ? "connected" : s));
          setIsLoading(false);
        }, 50);
      } else {
        setCallStatus("connected");
        setIsLoading(false);
      }
    } catch (error) {
      safeLogError("❌ Error starting call:", error);
      setIsLoading(false);
      setCallStatus("disconnected");
      setCall(null);
      alert("❌ Failed to start call.");
    }
  };

  // 🔹 End call
  const handleEndCall = async () => {
    if (!call) return;
    try {
      setCallStatus("ending");
      if (typeof call.stop === "function") {
        await call.stop();
      } else if (typeof call.end === "function") {
        await call.end();
      } else if (typeof call.disconnect === "function") {
        await call.disconnect();
      } else if (typeof call.hangUp === "function") {
        await call.hangUp();
      }
      setCallStatus("ended");
      setCall(null);
      setEventHandlers(null);

      setTimeout(() => {
        setCallStatus((s) =>
          s === "ending" || s === "ended" ? "disconnected" : s
        );
      }, 3000);
    } catch (error) {
      safeLogError("❌ Error ending call:", error);
      setCallStatus("ended");
      setCall(null);
      setEventHandlers(null);
      setTimeout(() => setCallStatus("disconnected"), 2000);
    } finally {
      setIsLoading(false);
    }
  };

  // 🔹 Helpers
  const getStatusColor = () => {
    switch (callStatus) {
      case "connected":
        return "bg-green-500";
      case "connecting":
        return "bg-yellow-500";
      case "ending":
        return "bg-orange-500";
      case "ended":
        return "bg-blue-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusText = () => {
    switch (callStatus) {
      case "connected":
        return "Connected to Agent";
      case "connecting":
        return "Connecting...";
      case "ending":
        return "Ending Call...";
      case "ended":
        return "Call Ended";
      default:
        return "Ready to Call";
    }
  };

  return (
    <div className="bg-background">
      <SignedOut>
        <div className="flex flex-col items-center justify-center h-screen">
          <h1 className="text-2xl font-bold text-white mb-6">Please Sign In</h1>
          <SignInButton mode="modal">
            <Button>Sign In</Button>
          </SignInButton>
        </div>
      </SignedOut>

      <SignedIn>
        <div className="fixed top-4 right-4">
          <UserButton afterSignOutUrl="/" />
        </div>

        {callStatus !== "disconnected" && (
          <div className="fixed top-4 left-4 z-50">
            <div
              className={`${getStatusColor()} text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2`}
            >
              <span className="text-sm font-medium">{getStatusText()}</span>
              {callStatus === "connected" && (
                <Button
                  onClick={handleEndCall}
                  variant="destructive"
                  size="sm"
                  className="ml-2 h-8 px-3"
                >
                  <PhoneOff className="h-4 w-4 mr-1" />
                  End Call
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Hero Section */}
        <section className="relative overflow-hidden py-32">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <Badge
                  variant="outline"
                  className="bg-blue-900/30 border-blue-700/30 px-4 py-2 text-blue-400 text-sm font-medium"
                >
                  Legal expertise made accessible
                </Badge>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
                  Connect with expert lawyers <br />
                  <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                    on your schedule
                  </span>
                </h1>
                <p className="text-muted-foreground text-lg md:text-xl max-w-md">
                  Book consultations, get legal advice, and manage your case all
                  in one secure platform designed for your legal needs.
                </p>
              </div>

              <div className="relative h-[400px] lg:h-[500px] rounded-xl overflow-hidden">
                <Image
                  src="/hero.png"
                  alt="Lawyer consultation"
                  fill
                  priority
                  className="object-cover rounded-xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Agent Communication Section */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Need Guidance Finding the Right Lawyer?
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Talk to our legal concierge, share your requirements, and we'll
                connect you with the perfect legal expert for your specific
                needs.
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <Card className="bg-gradient-to-r from-blue-900/20 to-blue-950/10 border-blue-800/30">
                <CardContent className="p-8 md:p-12">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                    <div className="space-y-6">
                      <div className="flex items-center">
                        <div className="bg-blue-900/20 p-3 rounded-full mr-4">
                          <MessageCircle className="h-8 w-8 text-blue-400" />
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold text-white">
                            Share Your Details
                          </h3>
                          <p className="text-muted-foreground">
                            Tell us about your legal needs
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="bg-blue-900/10 p-8 rounded-2xl border border-blue-800/30">
                        <div className="bg-blue-900/20 p-4 rounded-full inline-flex items-center justify-center mb-6">
                          <Phone className="h-10 w-10 text-blue-400" />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-4">
                          Start a Call
                        </h3>
                        <p className="text-muted-foreground mb-6">
                          Speak directly with our legal concierge to discuss
                          your requirements
                        </p>

                        {callStatus === "connected" ? (
                          <Button
                            onClick={handleEndCall}
                            variant="destructive"
                            className="py-6 px-8 text-lg"
                          >
                            <PhoneOff className="mr-2 h-5 w-5" /> End Call
                          </Button>
                        ) : (
                          <Button
                            onClick={handleStartCall}
                            disabled={
                              isLoading ||
                              callStatus === "connecting" ||
                              callStatus === "ending"
                            }
                            className="bg-blue-600 hover:bg-blue-700 text-white py-6 px-8 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {isLoading || callStatus === "connecting" ? (
                              <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                                {callStatus === "connecting"
                                  ? "Connecting..."
                                  : "Starting..."}
                              </>
                            ) : (
                              <>
                                <Phone className="mr-2 h-5 w-5" /> Start Call
                                Now
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </SignedIn>
    </div>
  );
}
