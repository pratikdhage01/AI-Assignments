"use client";
import { useUser } from "@clerk/nextjs";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Calendar } from "lucide-react";
import LawyerAppointmentsList from "@/components/appointments";

export default function AdminDashboardPage() {
  const { user } = useUser();
  const router = useRouter();
  const [isAuthorized, setIsAuthorized] = useState(false); // track admin access
  const [checking, setChecking] = useState(true); // to avoid showing page before check

  useEffect(() => {
    if (!user) return; // wait until user loads

    if (user.publicMetadata?.role === "admin") {
      setIsAuthorized(true);
    } else {
      alert("Access Denied! Redirecting to home.");
      router.replace("/"); // redirect non-admin
    }

    setChecking(false);
  }, [user, router]);

  if (checking) {
    return <p className="p-4">Checking permissions...</p>;
  }

  if (!isAuthorized) {
    return null; // content hidden while redirecting
  }

  return (
    <Tabs defaultValue="appointments" className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <TabsList className="md:col-span-1 bg-muted/30 border h-14 md:h-32 flex sm:flex-row md:flex-col w-full p-2 md:p-1 rounded-md md:space-y-2 sm:space-x-2 md:space-x-0">
        <TabsTrigger
          value="appointments"
          className="flex-1 md:flex md:items-center md:justify-start md:px-4 md:py-3 w-full"
        >
          <Calendar className="h-4 w-4 mr-2 hidden md:inline" />
          <span>Booked Appointments</span>
        </TabsTrigger>
      </TabsList>
      <div className="md:col-span-3">
        <TabsContent value="appointments" className="border-none p-0">
          <LawyerAppointmentsList />
        </TabsContent>
      </div>
    </Tabs>
  );
}
