
import { PageHeader } from "@/components/page-header";

export const metadata = {
  title: "Admin Dashboard - Lawgic.ai",
  description: "Manage your legal platform administration",
};

export default async function AdminDashboardLayout({ children }) {
  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        
        title="Admin Dashboard"
        subtitle="Manage users, lawyers, and platform settings"
      />

      {children}
    </div>
  );
}